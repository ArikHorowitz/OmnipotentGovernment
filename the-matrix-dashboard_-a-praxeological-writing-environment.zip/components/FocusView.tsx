
import React, { useState, useEffect, useRef } from 'react';
import type { Chapter, Lens, LensKey } from '../types';

interface FocusViewProps {
  chapter: Chapter;
  lenses: Lens[];
  onClose: () => void;
}

export const FocusView: React.FC<FocusViewProps> = ({ chapter, lenses, onClose }) => {
  const draftKey = `matrix-draft-${chapter.id}`;
  const [draft, setDraft] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Load from localStorage on mount
  useEffect(() => {
    const savedDraft = localStorage.getItem(draftKey);
    if (savedDraft) {
      setDraft(savedDraft);
    }
  }, [draftKey]);

  // Debounced save to localStorage
  useEffect(() => {
    const handler = setTimeout(() => {
      localStorage.setItem(draftKey, draft);
    }, 500);

    return () => {
      clearTimeout(handler);
    };
  }, [draft, draftKey]);
  
  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [draft]);

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-slate-800 rounded-lg shadow-2xl w-full max-w-6xl h-[90vh] flex flex-col ring-1 ring-slate-700" onClick={(e) => e.stopPropagation()}>
        <header className="flex justify-between items-center p-4 border-b border-slate-700">
          <div>
            <h2 className="text-xl font-bold text-slate-100">Focus: {chapter.title}</h2>
            <p className="text-sm text-slate-400">Part {chapter.part} / Chapter {chapter.chapter}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full text-slate-400 hover:bg-slate-700 hover:text-cyan-400 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-500">
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </header>
        <div className="flex-grow flex flex-col md:flex-row overflow-hidden">
          {/* Left Panel: Matrix Data */}
          <aside className="w-full md:w-1/3 h-1/2 md:h-full overflow-y-auto p-4 border-b md:border-r md:border-b-0 border-slate-700">
            <div className="space-y-4">
              {lenses.map(lens => {
                  const content = lens.id === 'synthesis' ? chapter.synthesis : chapter.lenses[lens.id as LensKey];
                  return (
                    <div key={lens.id}>
                      <h4 className="font-semibold text-sm text-slate-300 flex items-center gap-2">
                        <span>{lens.emoji}</span>
                        <span>{lens.name}</span>
                      </h4>
                      <p className="text-slate-400 text-sm mt-1 pl-1 border-l-2 border-slate-600" dangerouslySetInnerHTML={{ __html: content }}></p>
                    </div>
                  );
              })}
            </div>
          </aside>
          {/* Right Panel: Text Editor */}
          <main className="w-full md:w-2/3 h-1/2 md:h-full flex flex-col">
            <textarea
              ref={textareaRef}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Begin drafting here..."
              className="w-full flex-grow p-6 bg-slate-800 text-slate-200 text-lg leading-relaxed resize-none focus:outline-none placeholder-slate-500"
            ></textarea>
          </main>
        </div>
      </div>
    </div>
  );
};
