
import React from 'react';
import type { PartData, Lens, LensKey, Chapter } from '../types';
import { FilterControls } from './FilterControls';
import { ChapterCard } from './ChapterCard';

interface DashboardProps {
  parts: PartData[];
  lenses: Lens[];
  activePart: PartData;
  activeFilter: LensKey | 'all';
  onSelectPart: (partId: number) => void;
  onSelectFilter: (filter: LensKey | 'all') => void;
  onOpenFocusMode: (chapter: Chapter) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  parts,
  lenses,
  activePart,
  activeFilter,
  onSelectPart,
  onSelectFilter,
  onOpenFocusMode,
}) => {
  return (
    <div className="p-4 sm:p-6">
      <div className="mb-6">
        <div className="border-b border-slate-700">
          <nav className="-mb-px flex space-x-6" aria-label="Tabs">
            {parts.map((part) => (
              <button
                key={part.id}
                onClick={() => onSelectPart(part.id)}
                className={`${
                  activePart.id === part.id
                    ? 'border-cyan-400 text-cyan-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-500'
                } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 rounded-t-md`}
              >
                Part {part.id}
              </button>
            ))}
          </nav>
        </div>
        <h2 className="text-lg font-semibold text-slate-200 mt-4">{activePart.title}</h2>
      </div>

      <FilterControls
        lenses={lenses.filter(l => l.id !== 'synthesis') as Lens[]}
        activeFilter={activeFilter}
        onSelectFilter={onSelectFilter}
      />

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activePart.chapters.map((chapter) => (
          <ChapterCard
            key={chapter.id}
            chapter={chapter}
            lenses={lenses}
            activeFilter={activeFilter}
            onOpenFocusMode={() => onOpenFocusMode(chapter)}
          />
        ))}
      </div>
    </div>
  );
};
