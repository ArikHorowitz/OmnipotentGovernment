
import React from 'react';
import type { Lens, LensKey } from '../types';

interface FilterControlsProps {
  lenses: Lens[];
  activeFilter: LensKey | 'all';
  onSelectFilter: (filter: LensKey | 'all') => void;
}

export const FilterControls: React.FC<FilterControlsProps> = ({ lenses, activeFilter, onSelectFilter }) => {
  return (
    <div>
      <h3 className="text-md font-semibold text-slate-300 mb-3">Thematic Lens Audit</h3>
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => onSelectFilter('all')}
          className={`px-3 py-1 text-sm font-medium rounded-full transition-all duration-200 ${
            activeFilter === 'all'
              ? 'bg-cyan-400 text-slate-900 shadow-md'
              : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600/70'
          }`}
        >
          All
        </button>
        {lenses.map((lens) => (
          <button
            key={lens.id}
            onClick={() => onSelectFilter(lens.id as LensKey)}
            className={`px-3 py-1 text-sm font-medium rounded-full transition-all duration-200 flex items-center gap-2 ${
              activeFilter === lens.id
                ? 'bg-cyan-400 text-slate-900 shadow-md'
                : 'bg-slate-700/50 text-slate-300 hover:bg-slate-600/70'
            }`}
          >
            <span>{lens.emoji}</span>
            <span>{lens.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
