
import React, { useState, useCallback } from 'react';
import { Dashboard } from './components/Dashboard';
import { FocusView } from './components/FocusView';
import { MATRIX_DATA, LENSES } from './constants';
import type { Chapter, LensKey } from './types';

function App() {
  const [activePartId, setActivePartId] = useState<number>(1);
  const [activeFilter, setActiveFilter] = useState<LensKey | 'all'>('all');
  const [focusedChapter, setFocusedChapter] = useState<Chapter | null>(null);

  const handleSelectPart = useCallback((partId: number) => {
    setActivePartId(partId);
  }, []);

  const handleSelectFilter = useCallback((filter: LensKey | 'all') => {
    setActiveFilter(filter);
  }, []);

  const handleOpenFocusMode = useCallback((chapter: Chapter) => {
    setFocusedChapter(chapter);
  }, []);

  const handleCloseFocusMode = useCallback(() => {
    setFocusedChapter(null);
  }, []);

  const activePartData = MATRIX_DATA.find(p => p.id === activePartId) || MATRIX_DATA[0];

  return (
    <div className="min-h-screen font-sans">
      <header className="p-4 sm:p-6 border-b border-slate-700/50 bg-slate-900/70 backdrop-blur-sm sticky top-0 z-20">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-100">The Matrix Dashboard</h1>
        <p className="text-sm text-slate-400 mt-1">A Praxeological Writing Environment</p>
      </header>
      
      <main>
        <Dashboard
          parts={MATRIX_DATA}
          lenses={LENSES}
          activePart={activePartData}
          activeFilter={activeFilter}
          onSelectPart={handleSelectPart}
          onSelectFilter={handleSelectFilter}
          onOpenFocusMode={handleOpenFocusMode}
        />
      </main>

      {focusedChapter && (
        <FocusView
          chapter={focusedChapter}
          lenses={LENSES}
          onClose={handleCloseFocusMode}
        />
      )}
    </div>
  );
}

export default App;
