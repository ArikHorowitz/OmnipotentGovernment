
export type LensKey = 
  | 'institutionalLogic' 
  | 'narrativePower' 
  | 'psychologicalDynamics' 
  | 'humanAgency' 
  | 'informationControl' 
  | 'artisticPoetic' 
  | 'rhetoricalTone' 
  | 'philosophicalEpistemic';

export interface Lens {
  id: LensKey | 'all' | 'synthesis';
  name: string;
  emoji: string;
  color: string;
}

export interface Chapter {
  id: string;
  part: number;
  chapter: number;
  title: string;
  lenses: Record<LensKey, string>;
  synthesis: string;
}

export interface PartData {
  id: number;
  title: string;
  chapters: Chapter[];
}
